# Split-screen replay

Open http://localhost:9001/rts-arena/ in a fresh tab.

```sh
upload /workspace/match.tar.gz
gzip -dc /workspace/match.tar.gz | tar -xf - -C /workspace
rts-arena --replay /workspace/rts-high-vs-xhigh
```

Choose `rts-high-vs-xhigh-replay.tar.gz` in the upload picker.
Space pauses both games and thinking; +/- changes speed; Escape exits.
No model credentials or network calls are needed.

Player 1: Astra high. Player 2: Astra xhigh.
Player 2 won at frame 27,741. This bundle contains the native simulations,
recorded camera/input actions and streamed thinking/tool events.
